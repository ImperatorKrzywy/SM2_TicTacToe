#include "MKL05Z4.h"
#include <stdint.h>
#include "spi_lib.h"


void SPI_Init(){
	
		SIM->SCGC5 |= (SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK);
    SIM->SCGC4 |= SIM_SCGC4_SPI0_MASK;
	
    PORTA->PCR[6] = PORT_PCR_MUX(3); /* SPI0 MISO	(PTA6) */
    PORTA->PCR[7] = PORT_PCR_MUX(3); /* SPI0 MOSI	(PTA7) */
    PORTB->PCR[0] = PORT_PCR_MUX(3); /* SPI0 SCK	(PTB0) */
    PORTA->PCR[5] = PORT_PCR_MUX(3); /* SPI0 SS	(PTA5) */
	
	SPI0->C1 &= ~(0x07 << 2);  // Set MSTR, CPOL, CPHA bits
	SPI0->C1 |= (1 << 4);      // Set device as Master
	SPI0->BR = ((0x4 & 0x7) << 4) | (0x1 & 0xf); // Set speed to ~ 1 MHz
	SPI0->C1 |= SPI_C1_SPE_MASK; 
}

uint8_t spi_write(uint8_t send) {
	
	while(!(SPI0->S & SPI_S_SPTEF_MASK)); // Wait for TX buffer empty
    SPI0->D = send;
    while (!(SPI0->S & SPI_S_SPRF_MASK)); // Wait for RX buffer full
	return SPI0->D;
}


