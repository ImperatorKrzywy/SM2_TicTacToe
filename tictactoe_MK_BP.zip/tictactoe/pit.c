/*----------------------------------------------------------------------------
 *      Name:    pit.c
 *
 *      Purpose: Microprocessors Laboratory 2
 *      
 *      Author: Pawel Russek AGH University of Science and Technology
 *---------------------------------------------------------------------------*/
 
 /*Modified 18.01.2022   - added play_midi(void) and sel_melody(uint8_t mel_number)    */
 
#include "MKL05Z4.h"                    //Device header
#include "pit.h"												//Declarations
#include "tpm.h"

static const IRQn_Type myPIT_IRQn = 22;  /*-1 is not a correct value */	/* ToDo 6.1: Define interrupt (IRQ) number for PIT. Check MKL05Z4.h or find in NVIC section of KL05 Sub-Family Reference Manual - NVIC section */ 


 /*----------------------------------------------------------------------------
  Function that initializes PIT timer
 *----------------------------------------------------------------------------*/
void pitInitialize(unsigned period) {

	// Enable clock to PIT module
	SIM->SCGC6 |= SIM_SCGC6_PIT_MASK; /* ToDo 6.2 Enable PIT mask in SCGC6 register */
	
	// Enable module, freeze timers in debug mode
	PIT->MCR &= ~PIT_MCR_MDIS_MASK; /* ToDo 6.3 Disable MDIS mask in MCR register */
	PIT->MCR |= PIT_MCR_FRZ_MASK;   /* ToDo 6.4 Enable FRZ mask in MCR register */
	
	// Initialize PIT0 to count down from argument 
	PIT->CHANNEL[0].LDVAL = PIT_LDVAL_TSV(period);

	// No chaining
	PIT->CHANNEL[0].TCTRL &= PIT_TCTRL_CHN_MASK;
	
	// Generate interrupts
	PIT->CHANNEL[0].TCTRL |= PIT_TCTRL_TIE_MASK;

	/* Enable Interrupts */
	NVIC_SetPriority(myPIT_IRQn, 3); // 0, 1, 2 or 3 /* ToDo 7.2b, ToDo 7.3: Set PIT interrupt priority level  */

	NVIC_ClearPendingIRQ(myPIT_IRQn); 
	NVIC_EnableIRQ(myPIT_IRQn);	

}


void startPIT(void) {
// Enable counter
	PIT->CHANNEL[0].TCTRL |= PIT_TCTRL_TEN_MASK;
}

void stopPIT(void) {
// Enable counter
	PIT->CHANNEL[0].TCTRL &= ~PIT_TCTRL_TEN_MASK;
}


uint32_t melody_1[11] = { 311,349,415,349,262,349,415,466,415,311,262 };	// Start music
uint32_t duration_1[11] = {204,204,102,204,102,102,102,204,102,204,204};
uint32_t melody_2[9] = { 311,349,369,415,440,466,523,523,523 };				// Win music
uint32_t duration_2[9] = {281,140,140,140,140,140,281,281,140};
uint32_t melody_3[6] = { 466, 440, 466, 440, 392, 370 };					// Draw music
uint32_t duration_3[6] = {204, 204, 204, 204, 306, 612};
uint32_t melody_4[6] = { 311,277,233,147,165, 147};							// Lose music
uint32_t duration_4[6] = {204,204,204,409,600, 818};

float T = 0.0;
uint16_t mod = 0;
uint16_t cnt = 0;
uint16_t counter = 0;
uint16_t mel_counter = 0;
uint16_t n;
uint8_t repeat = 0;
uint8_t flag3 = 0xff;
uint8_t mel_sel = 0;
void sel_melody(uint8_t mel_number)
{
	mel_sel = mel_number;
}
void play_midi()
{
	
	counter += 1;  // Counts miliseconds 
	if(mel_sel == 0){      // Selected start music
		if(counter == duration_1[mel_counter]){  // Check for playing long enough
			if(flag3 ==0)  // Check for pause or playing
			{
				counter = 0;  
				mel_counter += 1;
				n = sizeof(melody_1)/sizeof(melody_1[0]);
				if(mel_counter == n) // Check for end of melody
				{
					if (repeat == 0){    // Repeat the melody twice
					mel_counter = 0;
					repeat += 1;
					}
					else{
						repeat = 0;
						mel_counter = 0;
						stopPIT();    // Turn off pit 
						PORTB->PCR[9] = PORT_PCR_MUX(1);		// Set PTB9 as GPIO(configured to output low)
					}					
				}
				T = (float)1/melody_1[mel_counter];  // Compute new period value
				mod = (T*SystemCoreClock)/128;       // Compute new modulo value
				cnt = mod /2;                        // Compute new cnv value (50% duty cycle)
				flag3 = ~flag3;                      // Set pause in next iteration
				TPM0_SetMod(mod);                    // Update modulo value
				TPM0_SetCnt(cnt);                    // Update cnv value
			}
			else
			{
				counter = 0;                         // Pause, that time = tone duration to separate different tones
				flag3 = ~flag3;				// Set tone in next iteration
				TPM0_SetMod(98);                     
				TPM0_SetCnt(0);
				
			}
		}
	}
	if(mel_sel == 1){  // Selected win music
		if(counter == duration_2[mel_counter]){ // Check for playing long enough
			if(flag3 ==0) // Check for pause or playing
			{
				counter = 0;
				mel_counter += 1;
				n = sizeof(melody_2)/sizeof(melody_2[0]);
				if(mel_counter == n)  // Check for end of melody
				{
					mel_counter = 0;
					stopPIT();  // Turn off pit
					PORTB->PCR[9] = PORT_PCR_MUX(1);	// Set PTB9 as GPIO(configured to output low)	
				}
				T = (float)1/melody_2[mel_counter];  // Compute new period value
				mod = (T*SystemCoreClock)/128;       // Compute new modulo value
				cnt = mod /2;                        // Compute new cnv value (50% duty cycle)
				flag3 = ~flag3;                      // Set pause in next iteration
				TPM0_SetMod(mod);                    // Update modulo value
				TPM0_SetCnt(cnt);                    // Update cnv value
			}
			else
			{
				counter = 0;    			// Pause, that time = tone duration to separate different tones
				flag3 = ~flag3;				// Set tone in next iteration
				TPM0_SetMod(98);
				TPM0_SetCnt(0);
				
			}
		}
	}
	else if(mel_sel == 2) // Selected draw music
	{
		
		if(counter == duration_3[mel_counter]) // Check for playing long enough
		{
			if(flag3 ==0)  // Check for pause or playing
			{
				counter = 0;
				mel_counter += 1;
				n = sizeof(melody_3)/sizeof(melody_3[0]);
				if(mel_counter == n)  // Check for end of melody
				{
					mel_counter = 0;
					stopPIT();  // Turn off pit
					PORTB->PCR[9] = PORT_PCR_MUX(1);		// Set PTB9 as GPIO(configured to output low)	
				}
				T = (float)1/melody_3[mel_counter];  // Compute new period value
				mod = (T*SystemCoreClock)/128;       // Compute new modulo value
				cnt = mod /2;                        // Compute new cnv value (50% duty cycle)
				flag3 = ~flag3;                      // Set pause in next iteration
				TPM0_SetMod(mod);                    // Update modulo value
				TPM0_SetCnt(cnt);                    // Update cnv value
			}
			else
			{
				counter = 0;				// Pause, that time = tone duration to separate different tones
				flag3 = ~flag3;				// Set tone in next iteration
				TPM0_SetMod(98);
				TPM0_SetCnt(0);
				
			}
		}
	}
	else  // Selected lose music
	{
		
		if(counter == duration_4[mel_counter]) // Check for playing long enough
		{
			if(flag3 ==0)  // Check for pause or playing
			{
				counter = 0;
				mel_counter += 1;
				n = sizeof(melody_4)/sizeof(melody_4[0]);
				if(mel_counter == n) // Check for end of melody
				{
					mel_counter = 0;
					stopPIT();		// Turn off pit
					PORTB->PCR[9] = PORT_PCR_MUX(1);		// Set PTB9 as GPIO(configured to output low)	
				}
				T = (float)1/melody_4[mel_counter];  // Compute new period value
				mod = (T*SystemCoreClock)/128;       // Compute new modulo value
				cnt = mod /2;                        // Compute new cnv value (50% duty cycle)
				flag3 = ~flag3;  				// Set pause in next iteration
				TPM0_SetMod(mod);                    // Update modulo value
				TPM0_SetCnt(cnt);                    // Update cnv value
			}
			else
			{
				counter = 0;				// Pause, that time = tone duration to separate different tones
				flag3 = ~flag3;				// Set tone in next iteration
				TPM0_SetMod(98);
				TPM0_SetCnt(0);
				
			}
		}
	}
}


void PIT_IRQHandler() {
		
	// check to see which channel triggered interrupt 
	if (PIT->CHANNEL[0].TFLG & PIT_TFLG_TIF_MASK) {
		// clear status flag for timer channel 0
		PIT->CHANNEL[0].TFLG &= PIT_TFLG_TIF_MASK;
		// Do ISR work
		play_midi();
	} else if (PIT->CHANNEL[1].TFLG & PIT_TFLG_TIF_MASK) {
		// clear status flag for timer channel 1
		PIT->CHANNEL[1].TFLG &= PIT_TFLG_TIF_MASK;
	}

	//clear pending IRQ
	NVIC_ClearPendingIRQ(myPIT_IRQn);
	
}