#include <stdint.h>

#ifndef pit_h
#define pit_h


void pitInitialize(unsigned period);
void startPIT(void);
void stopPIT(void);
/**
 * @brief Play 1 ms of MIDI sound
 *
 */
void play_midi(void);
/**
 * @brief Send data to peripherial
 *
 * @param mel_number sets melody to be played (0 - start, 1 - win, 2 - draw, 3 - lose) 
 *
 */
void sel_melody(uint8_t mel_number);

#endif
