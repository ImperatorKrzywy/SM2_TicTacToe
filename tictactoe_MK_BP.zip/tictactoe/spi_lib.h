#include <stdint.h>

/**
 * @brief Initialize SPI 

 * Pin configuration:
 * PTA6 - MISO
 * PTA7 - MOSI
 * PTB0 - SCK
 * PTA5 - SS
 */
void SPI_Init(void);

/**
 * @brief Send data to peripherial

 * @param send 8-bit data to be sent. 
 
 */
uint8_t spi_write(uint8_t send);
