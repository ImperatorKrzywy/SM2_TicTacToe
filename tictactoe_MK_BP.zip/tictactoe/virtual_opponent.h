/**
 * Opponent immitation
 * This library contains logic used for opponent emulation.
 */
 
 /**
 * @brief Set opponent move
 * @param displayMap 3x3 matrix that holds current playground configuration
 * @param result 2x1 vector that holds, next move's XY coordinates(0-2)
 * @param lfsr 2x1 vector that holds current lfsr register value
 * @return uint8_t variable, that flags whether player lost the game(0 - keep playing, 1 - player lost the game)
 */
uint8_t opponent_move(uint8_t displayMap[3][3], uint8_t result[2], uint8_t lfsr[2]);

/**
 * @brief Check if player win
 * @param displayMap 3x3 matrix that holds current playground configuration
 * @return uint8_t variable, that flags whether the player won the game(0 - keep playing, 1 - player won the game)
 */
uint8_t check_for_win(uint8_t displayMap[3][3]);

/**
 * @brief Check if draw
 * @param displayMap 3x3 matrix that holds current playground configuration
 * @return uint8_t variable, that flags whether the draw occured(0 - keep playing, 1 - draw occured)
 */
uint8_t check_for_draw(uint8_t displayMap[3][3]);

/**
 * @brief Clear the playground
 * @param displayMap 3x3 matrix that holds current playground configuration
 */
void reset(uint8_t displayMap[3][3]);
