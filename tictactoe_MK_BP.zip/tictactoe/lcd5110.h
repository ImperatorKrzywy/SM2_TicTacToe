#include "MKL05Z4.h"

/**
 * Nokia 5110 LCD Driver
 * This library contains functions used for display operations.
 */
 
/**
 * @brief Clear the display
 */
void lcd_clear(void);

/**
 * @brief Set LCD configuration
 *
 * Pin configuration:
 * PTA8 - RESET
 * PTA9 - SCE
 * PTA10 - D/C
 */
void lcd_Init(void);

/**
 * @brief Write byte of data to the LCD display
 * 
 * @param dc decides whether sent byte is a LCD command or RAM data(0-command, 1-data)
 * @param data 8 bit data to send to the LCD display
 */
void lcd_write(uint8_t dc, uint8_t data);

/**
 * @brief Sets LCD's XY position to write data
 * 
 * @param x sets X-coordinate(0-83)
 * @param y sets Y-coordinate(0-5)
 */
void gotoXY(uint8_t x, uint8_t y);

/**
 * @brief Delay function
 * 
 * @param n sets amount of ms to delay
 */
void delay_ms(int n);

/**
 * @brief Draw the whole set of horizontal lines
 * 
 */
void draw_line_horizontal(void);

/**
 * @brief Draw vertical line
 * 
 * @param x decides at which X-coordinate the line will be drawn (0-83)
 */
void draw_line_vertical(uint8_t x);

/**
 * @brief Draw figure
 * 
 * @param x decides at which X-coordinate the figure will be drawn(0-83)
 * @param y decides at which Y-coordinate the figure will be drawn(0-47)
 * @param mode decides what figure will be drawn: 0 - "O" , 1 - "X", 2 - cursor, 3 - clear cursor.
 */
void draw_figure(uint8_t x, uint8_t y, uint8_t mode);

/**
 * @brief Draw the whole set of lines
 * 
 */
void print_mesh(void);

/**
 * @brief Print the "Draw" animation
 * 
 */
void print_final_draw(void);

/**
 * @brief Print the "Win" animation
 * 
 */
void print_final_win(void);

/**
 * @brief Print the "Lose" animation
 * 
 */
void print_final_lose(void);

/**
 * @brief Print the "Start" animation
 * 
 */
void print_start_screen(void);
