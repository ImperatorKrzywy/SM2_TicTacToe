#include <stdlib.h>
#include <stdint.h>


uint8_t opponent_move(uint8_t displayMap[3][3], uint8_t result[2], uint8_t lfsr [2])
{
	unsigned char j,i;
	uint8_t a = 2;                   
	uint8_t leave = 0;
	uint8_t if_lose = 0;
	uint8_t bit = 0;
	uint8_t older_part = 0;	
	for(j=0; j<2; j++)  // That loop firstly checks for possibility to win, then for necessity to block the player
	{
		if(j==0)
		{
			a = 2; // checking for computer win
		}
		else
		{
			a = 1; // checking for blocking player
		}
		for(i=0; i<3; i++)
		{
			if(displayMap[i][0] == a && displayMap[i][1] == a && displayMap[i][2] ==0)
			{
				displayMap[i][2] = 2;        // Update current playground matrix
				result[0] = i;               // Update next move's X coordinate
				result[1] = 2;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
			else if(displayMap[i][0] == a && displayMap[i][1] == 0 && displayMap[i][2] ==a)
			{
				displayMap[i][1] = 2;        // Update current playground matrix
				result[0] = i;               // Update next move's X coordinate
				result[1] = 1;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
			else if(displayMap[i][0] == 0 && displayMap[i][1] == a && displayMap[i][2] ==a)
			{
				displayMap[i][0] = 2;        // Update current playground matrix
				result[0] = i;               // Update next move's X coordinate
				result[1] = 0;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
					
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
		}
		if(leave == 1)
		{
			break;
		}
		for(i=0; i<3; i++)
		{
			if(displayMap[0][i] == a && displayMap[1][i] == a && displayMap[2][i] ==0)
			{
				displayMap[2][i] = 2;        // Update current playground matrix
				result[0] = 2;               // Update next move's X coordinate
				result[1] = i;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
			else if(displayMap[0][i] == a && displayMap[1][i] == 0 && displayMap[2][i] ==a)
			{
				displayMap[1][i] = 2;        // Update current playground matrix
				result[0] = 1;               // Update next move's X coordinate
				result[1] = i;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
			else if(displayMap[0][i] == 0 && displayMap[1][i] == a && displayMap[2][i] ==a)
			{
				displayMap[0][i] = 2;        // Update current playground matrix
				result[0] = 0;               // Update next move's X coordinate
				result[1] = i;				 // Update next move's Y coordinate
				if(a==2)
				{
					if_lose = 1;             // Player lost
				}
				leave = 1;                   // Set flag to leave the main for loop
				break;
			}
		}
		if(leave == 1)
		{
			break;
		}
		if(displayMap[0][0] == a && displayMap[1][1] == a && displayMap[2][2] == 0)
		{
			displayMap[2][2] = 2;        // Update current playground matrix
			result[0] = 2;               // Update next move's X coordinate
			result[1] = 2;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		else if(displayMap[0][0] == a && displayMap[1][1] == 0 && displayMap[2][2] == a)
		{
			displayMap[1][1] = 2;        // Update current playground matrix
			result[0] = 1;               // Update next move's X coordinate
			result[1] = 1;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		else if(displayMap[0][0] == 0 && displayMap[1][1] == a && displayMap[2][2] == a)
		{
			displayMap[0][0] = 2;        // Update current playground matrix
			result[0] = 0;               // Update next move's X coordinate
			result[1] = 0;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		else if(displayMap[2][0] == 0 && displayMap[1][1] == a && displayMap[0][2] == a)
		{
			displayMap[2][0] = 2;        // Update current playground matrix
			result[0] = 2;               // Update next move's X coordinate
			result[1] = 0;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		else if(displayMap[2][0] == a && displayMap[1][1] == 0 && displayMap[0][2] == a)
		{
			displayMap[1][1] = 2;        // Update current playground matrix
			result[0] = 1;               // Update next move's X coordinate
			result[1] = 1;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		else if(displayMap[2][0] == a && displayMap[1][1] == a && displayMap[0][2] == 0)
		{
			displayMap[0][2] = 2;        // Update current playground matrix
			result[0] = 0;               // Update next move's X coordinate
			result[1] = 2;				 // Update next move's Y coordinate
			if(a==2)
				{
					if_lose = 1;         // Player lost
				}
			leave = 1;                   // Set flag to leave the main for loop
			break;
		}
		if(leave == 1)
		{
			break;                       // Leave main for loop
		}
	}
	if(leave == 0)                       // Make random movement
	{
		uint8_t counter=0;
		uint8_t number;
		for(i = 0; i < 3; i++)
		{
			for(j=0;j<3;j++)
			{
				if(displayMap[i][j] ==0)
				{
					counter += 1;        // Count all empty fields
				}
			}
		}
		
		
		bit = ((lfsr[0] >> 0) ^ (lfsr[0] >> 2) ^ (lfsr[0] >> 3) ^ (lfsr[0] >> 5)) & 1u;  // Polynomial = x^8 + x^6 + x^5 + x^3 + 1
    lfsr[0] = (lfsr[0] >> 1) | (bit << 7);   // Update lfsr value
    older_part = lfsr[0] & (0xe << 4);    // Take only 3 most significant bits 
		older_part = (older_part >> 5);
		if(older_part > counter)    // Check for boundary conditions
		{
			older_part = counter;
		}
		else if(older_part == 0)
		{
			older_part = 1;
		}
		
		counter = 0;
		for(i = 0; i < 3; i++)           // Search for selected field
		{
			for(j=0;j<3;j++)
			{
				if(displayMap[i][j] ==0)
				{
					counter += 1;
					if(counter == older_part)            // Field found
					{
						displayMap[i][j] = 2;        // Update current playground matrix
						result[0] = i;               // Update next move's X coordinate
						result[1] = j;               // Update next move's Y coordinate
						leave = 1;                   // Set flag to leave the main for loop
						break;
					}
				}
			}
			if(leave == 1)
			{
				break;;                       // Leave main for loop
			}
		}
		
	}
	return if_lose;
}

uint8_t check_for_win(uint8_t displayMap[3][3])
{
	uint8_t counter=0;
	uint8_t win = 0;
	unsigned char i,j;
	for(i=0;i<3;i++)                     // Searching for three signs in each row
	{
		for(j=0;j<3;j++)
		{
			if(displayMap[i][j] == 1)
			{
				counter += 1;
			}
			
		}
		if(counter == 3)
		{
			win = 1;                     // Player won the game
			break;
		}
		else
		{
			counter = 0;
		}
	}
	for(i=0;i<3;i++)                      // Searching for three signs in each column                     
	{
		for(j=0;j<3;j++)
		{
			if(displayMap[j][i] == 1)
			{
				counter += 1;
			}
			
		}
		if(counter == 3)
		{
			win = 1;                     // Player won the game
			break;
		}
		else
		{
			counter = 0;
		}
	}
	if(win ==0)                            // Checking the diagonals
	{
		if(displayMap[0][0] == 1 && displayMap[1][1] == 1 && displayMap[2][2] == 1)
		{
			win = 1;
		}
		else if(displayMap[0][2] == 1 && displayMap[1][1] == 1 && displayMap[2][0] == 1)
		{
			win = 1;
		}
	}
	return win;
	
}

uint8_t check_for_draw(uint8_t displayMap[3][3])
{
	unsigned char i,j;
	uint8_t counter=0;
	uint8_t draw=0;
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			if(displayMap[i][j] == 0)
			{
				counter += 1;          // Count all empty fields
			}
		}
	}
	if(counter == 0)
	{
		draw = 1;                      // No empty fields 
	}
	return draw;
	
}

void reset(uint8_t displayMap[3][3])
{
	unsigned char i,j;
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			displayMap[i][j] = 0;   // Set all matrix values to 0 (clear the playground)
		}
	}
}