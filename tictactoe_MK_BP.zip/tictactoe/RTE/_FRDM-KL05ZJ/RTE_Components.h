
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'tictactoe' 
 * Target:  'FRDM-KL05ZJ' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "MKL05Z4.h"



#endif /* RTE_COMPONENTS_H */
