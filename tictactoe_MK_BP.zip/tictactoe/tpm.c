/******************************************************************************
 * This file is a part of the Sysytem Microprocessor Tutorial (C).            *
 ******************************************************************************/

/**
 * @file tpm.c
 * @author Koryciak
 * @date Nov 2020
 * @brief File containing definitions for TPM.
 * @ver 0.1
 */
 /* Modified 18.01.2022 */

#include "tpm.h"
#include "pit.h"
/******************************************************************************\
* Private definitions
\******************************************************************************/
/******************************************************************************\
* Private prototypes
\******************************************************************************/

/******************************************************************************\
* Private memory declarations
\******************************************************************************/
static uint8_t tpm0Enabled = 0;



void TPM0_Init_PWM(uint16_t modulo, uint16_t cnvalue) {
		
  SIM->SCGC6 |= SIM_SCGC6_TPM0_MASK;		// ToDo 3.1.1: Enable TPM0 mask in SCGC6 register
	SIM->SOPT2 |= SIM_SOPT2_TPMSRC(1);  // ToDo 3.1.1: Choose MCGFLLCLK clock source

	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK; // ToDo 3.1.2: Connect port B to clock
	PORTB->PCR[9] = PORT_PCR_MUX(2);		// ToDo 3.1.2: Set multiplekser to TPM0 for PTB9, get channel number (page 148 of the Reference Manual)

	TPM0->SC |= TPM_SC_PS(111);  					// ToDo 3.1.3: Set prescaler to 128
	TPM0->SC |= TPM_SC_CMOD(1);					// ToDo 3.1.4: For TMP0, select the internal input clock source

	TPM0->MOD = modulo; 										// ToDo 3.1.5: Set modulo value to maximum value from slider
	
// ToDo 3.1.6: Connect correct channel from TPM0 for "Edge-aligned PWM Low-true pulses" mode
	TPM0->SC &= ~TPM_SC_CPWMS_MASK; 		/* up counting */
	TPM0->CONTROLS[2].CnSC |= (TPM_CnSC_MSB_MASK | TPM_CnSC_ELSA_MASK); /* set Output on match, clear Output on reload */ 

	TPM0->CONTROLS[2].CnV = cnvalue; 				// ToDo 3.1.7: Set starting value to 50
	tpm0Enabled = 1;  /* set local flag */
}



void TPM0_SetCnt(uint32_t value) {
					 
		TPM0->CONTROLS[2].CnV = value;    
}
void TPM0_SetMod(uint32_t value) {
	 				
		TPM0->MOD  = value;    
}
