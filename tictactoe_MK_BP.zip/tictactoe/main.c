#include "MKL05Z4.h"
#include "lcd5110.h"
#include "spi_lib.h"
#include "frdm_bsp.h"
#include <stdlib.h>
#include "ADC.h"
#include "virtual_opponent.h"
#include "tsi.h"
#include "pit.h"
#include "tpm.h"


#define BUTTON_1_POS 1
#define BUTTON_2_POS 7

	uint8_t wynik_ok=0;
	uint16_t	wynik0, wynik1;
	uint8_t flag = 0;
	uint8_t flag2 = 0;
	uint16_t temp;
	uint8_t slider = 0;

	
int main(void)
{
  // Display some simple character animation
  //
	unsigned char i;
	slider = 0;
	uint8_t	kal_error;
	uint8_t score = 0;
	uint8_t opp_xy[2] = {0, 0};
	uint8_t lfsr[2] = {0x64, 0x00};
	uint8_t entry = 0;
	
	
	uint8_t row_sel = 0;
	uint8_t col_sel = 0;

	uint8_t displayMap[3][3] = {0};
	uint8_t figure_xpositions[3][3] = {
		{5,34,63},
		{5,34,63},
		{5,34,63}
	};
		uint8_t figure_ypositions[3][3] = {
		{2,2,2},
		{19,19,19},
		{36,36,36}
	};
uint8_t cursor_xpositions[3][3] = {
		{22,51,80},
		{22,51,80},
		{22,51,80}
		
	};
	uint8_t cursor_ypositions[3][3] = {
		{3,3,3},
		{20,20,20},
		{37,37,37}
	};
	
	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK; 
	PORTB->PCR[1] |= PORT_PCR_MUX(1);                       // Set Pin 1 MUX as GPIO 	- button
	PORTB->PCR[1] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;   // Enable pull-up resistor on Pin 1
	
	PORTB->PCR[7] |= PORT_PCR_MUX(1);                       // Set Pin 7 MUX as GPIO 	- button
	PORTB->PCR[7] |= PORT_PCR_PE_MASK | PORT_PCR_PS_MASK;   // Enable pull-up resistor on Pin 7
	
	PORTB->PCR[6] |= PORT_PCR_MUX(1);                       // Set Pin 6 MUX as GPIO - Back Light
	PTB->PDDR |= (1<<6);               											// Set as output
	PTB->PDOR &= ~(1<<6);               										// Set BL output low
	
	PORTB->PCR[9] |= PORT_PCR_MUX(1);                       // Set Pin 9 MUX as GPIO  - turning off melody
	PTB->PDDR |= (1<<9);               											// Set as output
	PTB->PDOR &= ~(1<<9);               										// Set output low
	
  SPI_Init();
  lcd_Init();
  lcd_clear();
	SysTick_Config( SystemCoreClock / 1000);          // Set SysTick interrupt every 1ms
	TSI_Init();
	

	
	kal_error=ADC_Init();				                    // Inicjalization and calibration of ADC
	if(kal_error)
	{	
		while(1);									        // Calibration failed
	}

	
	ADC0->SC1[0] = ADC_SC1_AIEN_MASK | ADC_SC1_ADCH(0);		// First trigger ADC0 on channel 0 and unblock the interrupt
	
	print_start_screen();
	TPM0_Init_PWM(1206, 603);           // Play start melody
	pitInitialize(20901);   
	startPIT();
	
	while(1){
		if( ( PTB->PDIR & (1<<BUTTON_2_POS) ) ==0 ){      // Check if button pressed				
			break;
		}
	}
	for (i = 0; i < 2; i++){
		lcd_clear();
		delay_ms(500);
		print_start_screen();
		delay_ms(1000);
	}
	lcd_clear();
	print_mesh();
	
  while(1){
		
		if(wynik_ok){

				draw_figure(cursor_xpositions[row_sel][col_sel], cursor_ypositions[row_sel][col_sel], 3); // Clear the cursor
			if (flag == 0){               // Set row using potentiometer
				if(wynik0 < 1356)

				{
					row_sel = 0;
				}
				else if(wynik0 < 2712 && wynik0 > 1357)
				{
					row_sel = 1;
				}
				else
				{
					row_sel = 2;
				}
				
				ADC0->SC1[0] = ADC_SC1_AIEN_MASK | ADC_SC1_ADCH(4);		// Switching to ADC canal 4
				flag = 1;
			}
		else if (flag == 1){               // Set column using potentiometer
				if(wynik1 < 1356)
				{
					col_sel = 0;
				}
				else if(wynik1 < 2712 && wynik1 > 1357)
				{
					col_sel = 1;
				}
				else
				{
					col_sel = 2;
				}
				ADC0->SC1[0] = ADC_SC1_AIEN_MASK | ADC_SC1_ADCH(0);		// Switching to ADC canal 0
				flag = 0;
		}

			draw_figure(cursor_xpositions[row_sel][col_sel], cursor_ypositions[row_sel][col_sel], 2); // Draw cursor
			if( ( PTB->PDIR & (1<<BUTTON_1_POS) ) ==0 ){      // Check if button pressed
				if(displayMap[row_sel][col_sel] == 0){        // Check whether the field is empty
					draw_figure(cursor_xpositions[row_sel][col_sel], cursor_ypositions[row_sel][col_sel], 3); // Clear cursor
					draw_figure(figure_xpositions[row_sel][col_sel], figure_ypositions[row_sel][col_sel], 1); // Draw cross
					displayMap[row_sel][col_sel] = 1;         // Update playground matrix
					score = check_for_win(displayMap);        // Check whether player won
					if(score ==1)							  // Player won					
					{
						reset(displayMap);		              // Clear the playground matrix
						sel_melody(1);                        // Select win melody
						PORTB->PCR[9] = PORT_PCR_MUX(2);		// Set PTB9 as PWM output
						TPM0_SetMod(1206);                      // Play win melody
					  TPM0_SetCnt(603);
						startPIT();
						print_final_win();                    // Print out the win animation
						print_mesh();	                      // Print out mesh			
						entry = ~entry;                       // Starting with first move anternately(once player, once computer)
						if (entry == 255) { // Computer starts
							opponent_move(displayMap , opp_xy, lfsr); // Make first move
							draw_figure(figure_xpositions[opp_xy[0]][opp_xy[1]], figure_ypositions[opp_xy[0]][opp_xy[1]], 0);
						}
					}
					else 
					{
						score = check_for_draw(displayMap);   // Check whether draw occured
						if(score==1)							  // Draw occured
						{
							reset(displayMap);		              // Clear the playground matrix
							sel_melody(2);                      // Select draw melody
							PORTB->PCR[9] = PORT_PCR_MUX(2);		// Set PTB9 as PWM output
							TPM0_SetMod(804);						// Play draw melody
							TPM0_SetCnt(402);
							startPIT();
							print_final_draw();                   // Print out the draw animation
							print_mesh();	                      // Print out mesh
							entry = ~entry;
							if (entry == 255) {	// Computer starts
								opponent_move(displayMap, opp_xy, lfsr);	// Make first move
								draw_figure(figure_xpositions[opp_xy[0]][opp_xy[1]], figure_ypositions[opp_xy[0]][opp_xy[1]], 0);
							}
						}
						else
						{
							score = opponent_move(displayMap, opp_xy, lfsr);   // Opponent move
							if(score==1)								 // Player lost the game
							{
								reset(displayMap);		              // Clear the playground matrix
								sel_melody(3);							// Select lose melody
								PORTB->PCR[9] = PORT_PCR_MUX(2);		// Set PTB9 as PWM output
								TPM0_SetMod(1206);						// Play lose melody
								TPM0_SetCnt(603);
								startPIT();
								print_final_lose();                   // Print out the lose animation
								print_mesh();	                      // Print out mesh
								entry = ~entry;
								if (entry == 255) {	// Computer starts
									opponent_move(displayMap, opp_xy, lfsr);	// Make first move
									draw_figure(figure_xpositions[opp_xy[0]][opp_xy[1]], figure_ypositions[opp_xy[0]][opp_xy[1]], 0);
								}
							}
							else
							{
								draw_figure(figure_xpositions[opp_xy[0]][opp_xy[1]], figure_ypositions[opp_xy[0]][opp_xy[1]], 0); // Draw circle(opponent move)
								score = check_for_draw(displayMap);   // Check whether draw occured
								if(score==1)							  // Draw occured
								{
									reset(displayMap);		              // Clear the playground matrix
									sel_melody(2);		// Select draw melody
									PORTB->PCR[9] = PORT_PCR_MUX(2);		// Set PTB9 as PWM output
									TPM0_SetMod(3232);						// Play draw melody
									TPM0_SetCnt(1616);
									startPIT();
									print_final_draw();                   // Print out the draw animation
									print_mesh();	                      // Print out mesh
									entry = ~entry;
								}
							}
						}
					}
				}
				while( ( PTB->PDIR & (1<<BUTTON_1_POS) ) == 0 ) // Debouncing
				delay_ms(100);
			}
			wynik_ok=0;

			}
		}
	}




void ADC0_IRQHandler()
{	
	temp = ADC0->R[0];	// Reading the data and deleting the COCO flag
	if(!wynik_ok)				// Check if the result consumed by the main loop
	{
		if (flag == 0){
			wynik0 = temp;			// Send new data to the main loop
			wynik_ok=1;
		}
		else if (flag == 1){
			wynik1 = temp;			// Send new data to the main loop
			wynik_ok=1;
		}

	}
	NVIC_EnableIRQ(ADC0_IRQn);
}

void SysTick_Handler(void) {
	slider = TSI_ReadSlider();
	if (slider != 0) {
		if (slider > 50){
				PTB->PDOR |= (1<<6);               											// Set BL output high
		}
		else {
				PTB->PDOR &= ~(1<<6);               											// Set BL output low
		}
	}												
}
